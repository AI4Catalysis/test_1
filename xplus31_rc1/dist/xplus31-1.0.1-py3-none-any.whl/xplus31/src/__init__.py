from . import merge
from .minus import file_1 # as if file_1 located similar as file5 & file7
from . import file5
from . import file7
print('src imported')
def alert():
    print(Exception)