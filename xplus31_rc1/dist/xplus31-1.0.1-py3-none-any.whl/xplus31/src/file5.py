def plus5(x):
    'lambda x : x+5'
    return x+5