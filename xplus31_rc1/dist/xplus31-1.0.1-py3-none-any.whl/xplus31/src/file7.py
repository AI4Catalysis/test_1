def plus7(x):
    'lambda x : x+7'
    return x+7