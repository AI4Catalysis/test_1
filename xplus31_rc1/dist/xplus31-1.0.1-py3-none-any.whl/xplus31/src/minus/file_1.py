def minus1(x):
    'lambda x : x-1'
    return x-1