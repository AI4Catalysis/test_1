### What is this
This is a project which mainly contains simple functions like this:
```python
    plus31 = lambda x : x + 31
```
The purpose to create this project is to practicing package distribution.

### How to import its functions
For practice, the directory is designed very complex.
However, with model `calcfun`, import will be easy.
We have function/variables named plus5,plus7,minus1,plus13,plus31,const,print_clr under `calcfun`.
We can:
```python
    assert xplus31.src.merge.deeper.file31.plus31 is xplus31.calcfun.plus31
    assert xplus31.calcfun.plus31(79) == 100
```
,etc.
### Ester-eggs:
Find it yourself!