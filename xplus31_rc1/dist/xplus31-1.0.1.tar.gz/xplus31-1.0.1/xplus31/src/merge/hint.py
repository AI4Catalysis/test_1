def hint(x):
    'print'
    print(x)